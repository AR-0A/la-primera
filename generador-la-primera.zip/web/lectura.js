const root = document.documentElement;
const tema = document.querySelector('.tema');
const preferencia = window.matchMedia('(prefers-color-scheme: dark)');
let eleccion;
try { eleccion = localStorage.getItem('la-primera-tema'); } catch { /* lectura local */ }

function aplicarTema(oscuro) {
  root.dataset.tema = oscuro ? 'oscuro' : 'claro';
  tema.setAttribute('aria-pressed', String(oscuro));
  document.querySelector('meta[name="theme-color"]').content = oscuro ? '#211e1d' : '#f9f7f1';
}

aplicarTema(eleccion ? eleccion === 'oscuro' : preferencia.matches);
tema.hidden = false;
tema.addEventListener('click', () => {
  aplicarTema(root.dataset.tema !== 'oscuro');
  eleccion = root.dataset.tema;
  try { localStorage.setItem('la-primera-tema', eleccion); } catch { /* lectura local */ }
});
preferencia.addEventListener('change', ({matches}) => {
  if (!eleccion) aplicarTema(matches);
});

const ficha = document.querySelector('.ficha');
const enlacesGlosario = [...document.querySelectorAll('.termino')];
for (const enlace of enlacesGlosario) {
  enlace.addEventListener('click', (event) => {
    if (event.metaKey || event.ctrlKey || event.shiftKey || event.altKey) return;
    const entrada = document.getElementById(enlace.hash.slice(1));
    if (!entrada || typeof ficha.showModal !== 'function') {
      if (entrada) entrada.open = true;
      return;
    }
    event.preventDefault();
    ficha.querySelector('#ficha-nombre').textContent = entrada.querySelector('summary').textContent;
    ficha.querySelector('.ficha-ampliacion').textContent = entrada.querySelector('.ampliacion').textContent;
    ficha.querySelector('.ficha-definicion').textContent = entrada.querySelector('.definicion').textContent;
    const fuente = entrada.querySelector('a');
    const destino = ficha.querySelector('.ficha-fuente');
    destino.textContent = fuente.textContent;
    destino.href = fuente.href;
    ficha.showModal();
  });
}
ficha.addEventListener('click', (event) => {
  if (event.target === ficha) ficha.close();
});

const aviso = document.querySelector('.aviso');
if (aviso) {
  const partes = new Intl.DateTimeFormat('es', {timeZone: 'Europe/Madrid', year: 'numeric', month: '2-digit', day: '2-digit'}).formatToParts(new Date());
  const fecha = Object.fromEntries(partes.map(({type, value}) => [type, value]));
  aviso.hidden = document.querySelector('.fecha-dia').dateTime === `${fecha.year}-${fecha.month}-${fecha.day}`;
}

const controlesGlosario = document.querySelector('.controles-glosario');
const buscador = controlesGlosario.querySelector('input[type="search"]');
const filtroEdicion = controlesGlosario.querySelector('input[type="checkbox"]');
const entradas = [...document.querySelectorAll('.entrada')];
const terminosEdicion = new Set(enlacesGlosario.map((enlace) => enlace.hash.slice(1)));
const normalizar = (texto) => texto.normalize('NFD').replace(/\p{Diacritic}/gu, '').toLowerCase();
function filtrarGlosario() {
  const consulta = normalizar(buscador.value.trim());
  for (const entrada of entradas) {
    const encajaEnEdicion = !filtroEdicion.checked || terminosEdicion.has(entrada.id);
    entrada.hidden = !encajaEnEdicion || !normalizar(entrada.textContent).includes(consulta);
  }
  document.querySelector('#sin-terminos').hidden = entradas.some((entrada) => !entrada.hidden);
}
controlesGlosario.hidden = false;
buscador.addEventListener('input', filtrarGlosario);
filtroEdicion.addEventListener('change', filtrarGlosario);
filtrarGlosario();

if ('serviceWorker' in navigator && isSecureContext && location.protocol !== 'file:') {
  navigator.serviceWorker.register(`${document.body.dataset.base}sw.js`).catch(() => {});
}
