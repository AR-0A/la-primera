import argparse
import concurrent.futures
import hashlib
import html
import ipaddress
import json
import math
import os
import re
import shutil
import socket
import struct
import tempfile
import unicodedata
import zlib
from datetime import date, datetime, timedelta, timezone
from email.utils import parsedate_to_datetime
from functools import partial
from html.parser import HTMLParser
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from string import Template
from urllib.parse import parse_qsl, urlparse
from urllib.request import Request, urlopen
from xml.etree import ElementTree


ROOT = Path(__file__).resolve().parent
WEB = ROOT / 'web'
DIST = ROOT / 'dist'
LOCAL = ROOT / '.local'
SECTIONS = ('España', 'Mundo', 'Política', 'Economía', 'Deportes', 'Ciencia', 'Tecnología', 'Cultura y cine', 'Agenda')
MONTHS = 'enero febrero marzo abril mayo junio julio agosto septiembre octubre noviembre diciembre'.split()
DAYS = 'lunes martes miércoles jueves viernes sábado domingo'.split()
TERM = re.compile(r'\[\[([a-z0-9-]+)\|([^\[\]]+)\]\]')
ID = re.compile(r'[a-z0-9]+(?:-[a-z0-9]+)*')
MAX_FEED = 2_000_000
ESC = html.escape


def read_json(path):
    return json.loads(path.read_text(encoding='utf-8'))


def write_atomic(path, content):
    path.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.NamedTemporaryFile(dir=path.parent, delete=False) as temp:
        temp.write(content if isinstance(content, bytes) else content.encode('utf-8'))
    temporary = Path(temp.name)
    try:
        temporary.replace(path)
    finally:
        temporary.unlink(missing_ok=True)


def spanish_date(value):
    day = date.fromisoformat(value)
    return f'{DAYS[day.weekday()].capitalize()}, {day.day} de {MONTHS[day.month - 1]} de {day.year}'


def url(value):
    parsed = urlparse(value)
    if parsed.scheme != 'https' or not parsed.hostname or parsed.username or parsed.password:
        raise ValueError(f'Se necesita un enlace HTTPS público: {value}')
    return ESC(value)


def slug(value):
    return re.sub(r'[^a-z0-9]+', '-', unicodedata.normalize('NFKD', value.lower()).encode('ascii', 'ignore').decode()).strip('-')


def marked(value, glossary):
    pieces = []
    end = 0
    for match in TERM.finditer(value):
        key, label = match.groups()
        if key not in glossary:
            raise ValueError(f'Término sin definición: {key}')
        pieces.extend((ESC(value[end:match.start()]), f'<a class="termino" href="#termino-{key}">{ESC(label)}</a>'))
        end = match.end()
    pieces.append(ESC(value[end:]))
    return ''.join(pieces)


def load_content():
    glossary = read_json(ROOT / 'glosario.json')
    for key, entry in glossary.items():
        if not ID.fullmatch(key) or not all(entry[field].strip() for field in ('nombre', 'tema', 'definicion', 'fuente')):
            raise ValueError(f'Entrada de glosario inválida: {key}')
        url(entry['url'])

    editions = []
    for path in sorted((ROOT / 'ediciones').glob('????-??-??.json'), reverse=True):
        edition = read_json(path)
        if edition['estado'] != 'revisada':
            continue
        if date.fromisoformat(edition['fecha']).isoformat() != path.stem:
            raise ValueError(f'La fecha no coincide con el nombre de {path.name}')
        if edition.get('actualizada') is not None:
            updated = datetime.fromisoformat(edition['actualizada'])
            if updated.utcoffset() is None or updated.date().isoformat() < edition['fecha']:
                raise ValueError(f'La actualización debe tener una fecha válida y un huso horario: {path.name}')
            edition['actualizada'] = updated
        ids = set()
        for story in edition['noticias']:
            key = story['id']
            if not ID.fullmatch(key) or key in ids or story['seccion'] not in SECTIONS:
                raise ValueError(f'Identificador o sección inválida: {key}')
            ids.add(key)
            if not all(story[field].strip() for field in ('titulo', 'breve', 'texto')):
                raise ValueError(f'Falta título, breve o texto: {key}')
            if story['seccion'] == 'Deportes' and not story.get('deporte', '').strip():
                raise ValueError(f'Falta indicar el deporte: {key}')
            for field in ('texto', 'contexto', 'contraste'):
                marked(story.get(field, ''), glossary)
            sources = story['fuentes']
            if len({urlparse(link['url']).hostname for link in sources}) < 2:
                raise ValueError(f'Se necesitan fuentes de dos dominios distintos: {key}')
            for link in sources:
                url(link['url'])
            if story['seccion'] == 'Política' and (len(sources) < 3 or not story.get('contraste', '').strip()):
                raise ValueError(f'Falta contraste político: {key}')
            if photo := story.get('foto'):
                filename = photo['archivo']
                if not re.fullmatch(r'[a-z0-9-]+\.(jpg|png|webp)', filename) or not (ROOT / 'media' / filename).is_file():
                    raise ValueError(f'Falta un archivo de imagen válido: {filename}')
                url(photo['origen'])
                url(photo['licencia'])
        if edition['portada'] not in ids:
            raise ValueError(f'Portada inválida: {path.name}')
        editions.append(edition)
    if not editions:
        raise ValueError('Hace falta al menos una edición revisada.')
    return glossary, editions


def render_story(story, glossary, base, lead=False):
    heading = 'h2' if lead else 'h3'
    parts = [f'<article class="noticia{" principal" if lead else ""}" id="{story["id"]}">']
    sport = story.get('deporte')
    if lead:
        label = ' · '.join(filter(None, (story['seccion'], sport, 'Portada')))
        parts.append(f'<span class="etiqueta">{ESC(label)}</span>')
    elif sport:
        parts.append(f'<span class="etiqueta">{ESC(sport)}</span>')
    parts.append(f'<{heading}>{ESC(story["titulo"])}</{heading}>')
    plain_text = TERM.sub(lambda match: match[2], story['texto'])
    if plain_text.rstrip('.!?') != story['titulo'].rstrip('.!?') or TERM.search(story['texto']):
        parts.append(f'<p class="texto">{marked(story["texto"], glossary)}</p>')
    if context := story.get('contexto'):
        parts.append(f'<p class="contexto"><strong>Importancia.</strong> {marked(context, glossary)}</p>')
    parts.append(f'<details class="fuentes"><summary>Fuentes y contexto ({len(story["fuentes"])})</summary>')
    if contrast := story.get('contraste'):
        parts.append(f'<p class="contraste"><strong>Cómo se contó.</strong> {marked(contrast, glossary)}</p>')
    links = ''.join(f'<li><a href="{url(item["url"])}">{ESC(item["nombre"])}</a> · {ESC(item["rol"])}</li>' for item in story['fuentes'])
    parts.append(f'<ul>{links}</ul></details>')
    if correction := story.get('correccion'):
        parts.append(f'<p class="correccion"><strong>Corrección.</strong> {ESC(correction)}</p>')
    if lead and (photo := story.get('foto')):
        parts.append(f'<figure><img src="{base}media/{photo["archivo"]}" alt="{ESC(photo["alt"])}" fetchpriority="high">'
                     f'<figcaption>{ESC(photo["pie"])}. <a href="{url(photo["origen"])}">{ESC(photo["autor"])}</a> · '
                     f'<a href="{url(photo["licencia"])}">{ESC(photo["licencia_nombre"])}</a></figcaption></figure>')
    return ''.join(parts) + '</article>'


def render(edition, all_editions, glossary, template, css, js, base=''):
    by_id = {story['id']: story for story in edition['noticias']}
    lead = by_id[edition['portada']]
    by_section = {label: [] for label in SECTIONS}
    for story in by_id.values():
        by_section[story['seccion']].append(story)
    nav, groups, highlights = [], [], []
    for label, stories in by_section.items():
        if not stories:
            continue
        other_stories = [story for story in stories if story != lead]
        if other_stories:
            section_id = f'seccion-{slug(label)}'
            groups.append(f'<section id="{section_id}" class="bloque"><h2>{ESC(label)}</h2>' + ''.join(
                render_story(story, glossary, base) for story in other_stories) + '</section>')
        else:
            section_id = lead['id']
        nav.append(f'<a href="#{section_id}">{ESC(label)}</a>')

        links = []
        for story in stories:
            sport = f'<strong>{ESC(story["deporte"])}.</strong> ' if story.get('deporte') else ''
            links.append(f'<li><a href="#{story["id"]}">{sport}{ESC(story["breve"])}</a></li>')
        number = len(highlights) + 1
        highlights.append(f'<li class="indice-seccion"><span class="numero" aria-hidden="true">{number:02}</span>'
                          f'<div><h3>{ESC(label)}</h3><ul class="indice-noticias" role="list">{"".join(links)}</ul></div></li>')
    entries = []
    for key, item in sorted(glossary.items(), key=lambda pair: slug(pair[1]['nombre'])):
        entries.append(f'<details class="entrada" id="termino-{key}"><summary>{ESC(item["nombre"])}</summary>'
                       f'<p class="meta"><span class="ampliacion">{ESC(item["ampliacion"])}</span> · {ESC(item["tema"])}</p>'
                       f'<p class="definicion">{ESC(item["definicion"])}</p>'
                       f'<p class="meta"><a href="{url(item["url"])}">{ESC(item["fuente"])}</a></p></details>')
    archive = ''.join(f'<li><a href="{base}ediciones/{item["fecha"]}.html">{spanish_date(item["fecha"])}</a></li>' for item in all_editions)
    words = sum(len(story[field].split()) for story in by_id.values() for field in ('titulo', 'texto'))
    words += sum(len(story.get('contexto', '').split()) for story in by_id.values())
    label = spanish_date(edition['fecha'])
    update = ''
    if updated := edition.get('actualizada'):
        update_label = f'a las {updated:%H:%M}'
        if updated.date().isoformat() != edition['fecha']:
            update_label = f'el {updated.day} de {MONTHS[updated.month - 1]} de {updated.year} {update_label}'
        update = f'<span>Actualizada <time class="fecha-hora" datetime="{updated.isoformat()}">{update_label}</time></span>'
    warning = '' if base else '<p class="aviso" hidden>Esta es la última edición disponible.</p>'
    if edition.get('metodo') == 'automatico':
        warning += '<p class="aviso-contraste">Edición contrastada automáticamente a partir de las fuentes enlazadas.</p>'
    return template.substitute(titulo=f'La Primera · {label}', descripcion=ESC(edition['sumario']), base=base, css=css, js=js,
                               navegacion=''.join(nav), fecha_iso=edition['fecha'], fecha_texto=label, actualizada=update, aviso=warning,
                               tiempo=max(1, math.ceil(words / 190)), portada=render_story(lead, glossary, base, lead=True),
                               resumen=''.join(highlights), secciones=f'<div class="rejilla">{"".join(groups)}</div>',
                               glosario=''.join(entries), archivo=archive)


def icon(size):
    def chunk(kind, data):
        return struct.pack('>I', len(data)) + kind + data + struct.pack('>I', zlib.crc32(kind + data))

    rows = []
    for y in range(size):
        row = bytearray([0])
        for x in range(size):
            a, b = x / size, y / size
            page = .27 <= a <= .73 and .24 <= b <= .76
            lines = .34 <= a <= .66 and (.35 <= b <= .40 or .48 <= b <= .51 or .59 <= b <= .62)
            row.extend((249, 247, 241) if page and not lines else (142, 39, 45))
        rows.append(row)
    return (b'\x89PNG\r\n\x1a\n' + chunk(b'IHDR', struct.pack('>IIBBBBB', size, size, 8, 2, 0, 0, 0))
            + chunk(b'IDAT', zlib.compress(b''.join(rows), 9)) + chunk(b'IEND', b''))


def build():
    glossary, editions = load_content()
    template = Template((WEB / 'portada.html').read_text(encoding='utf-8'))
    css = (WEB / 'estilos.css').read_text(encoding='utf-8')
    js = (WEB / 'lectura.js').read_text(encoding='utf-8')
    latest = editions[0]
    home = render(latest, editions, glossary, template, css, js)
    assets = ['index.html', 'icon-192.png', 'icon-512.png', 'manifest.webmanifest']
    for edition in editions:
        write_atomic(DIST / 'ediciones' / f'{edition["fecha"]}.html', render(edition, editions, glossary, template, css, js, '../'))
        lead = next(story for story in edition['noticias'] if story['id'] == edition['portada'])
        if photo := lead.get('foto'):
            path = f'media/{photo["archivo"]}'
            (DIST / 'media').mkdir(parents=True, exist_ok=True)
            shutil.copyfile(ROOT / path, DIST / path)
            if edition == latest:
                assets.append(path)
    for size in (192, 512):
        write_atomic(DIST / f'icon-{size}.png', icon(size))
    manifest = {'name': 'La Primera', 'short_name': 'La Primera', 'id': './', 'lang': 'es', 'start_url': './',
                'scope': './', 'display': 'standalone', 'background_color': '#f9f7f1', 'theme_color': '#f9f7f1',
                'icons': [{'src': f'icon-{n}.png', 'sizes': f'{n}x{n}', 'type': 'image/png', 'purpose': 'any maskable'} for n in (192, 512)]}
    write_atomic(DIST / 'manifest.webmanifest', json.dumps(manifest, ensure_ascii=False))
    write_atomic(DIST / 'index.html', home)
    worker = Template((WEB / 'sw.js').read_text(encoding='utf-8'))
    version = hashlib.sha256((home + worker.template).encode()).hexdigest()[:16]
    write_atomic(DIST / 'sw.js', worker.substitute(version=version, assets=json.dumps(assets)))
    print(f'Edición {latest["fecha"]}: {len(latest["noticias"])} noticias. {DIST / "index.html"}')


def madrid_today():
    # Windows no incluye la base IANA en todas las instalaciones de Python.
    try:
        from zoneinfo import ZoneInfo
        return datetime.now(ZoneInfo('Europe/Madrid')).date()
    except KeyError:
        if os.name == 'nt':
            return datetime.now().date()
        raise


def parse_date(value):
    if not value:
        return None
    try:
        moment = parsedate_to_datetime(value)
    except ValueError:
        try:
            moment = datetime.fromisoformat(value.replace('Z', '+00:00'))
        except ValueError:
            return None
    return moment.replace(tzinfo=moment.tzinfo or timezone.utc).astimezone(timezone.utc)


class FeedText(HTMLParser):
    def __init__(self):
        super().__init__()
        self.parts = []
        self.suppress = None

    def handle_starttag(self, tag, attrs):
        if tag in ('script', 'style'):
            self.suppress = tag
        elif tag in ('br', 'p', 'li', 'div'):
            self.parts.append(' ')

    def handle_endtag(self, tag):
        if tag == self.suppress:
            self.suppress = None
        elif tag in ('p', 'li', 'div'):
            self.parts.append(' ')

    def handle_data(self, data):
        if self.suppress is None:
            self.parts.append(data)


def feed_text(value):
    parser = FeedText()
    parser.feed(value[:12_000])
    text = ' '.join(''.join(parser.parts).split())
    return re.split(r'(?i)\b(?:leer (?:la noticia|m[aá]s)|sigue leyendo)\b', text, maxsplit=1)[0].strip()


def feed_origin(source, item, description):
    author = ' '.join(child.text or '' for child in item if child.tag.split('}')[-1] in ('creator', 'author'))
    # Identifica las firmas conocidas sin confundir a una agencia citada dentro del texto con su autor.
    byline = re.sub(r'^[\s(]+', '', description).split(').-', 1)
    if len(byline) > 1:
        author += ' ' + byline[0]
    agency = re.search(r'\b(EFE|Europa Press|Reuters|AFP|Associated Press)\b', author, re.I)
    return agency[0].casefold() if agency else source['grupo'].casefold()


def read_feed(source, start, end):
    try:
        request = Request(source['url'], headers={'User-Agent': 'LaPrimera/1.0 (lector personal RSS)', 'Accept': 'application/rss+xml, application/atom+xml, application/xml, text/xml, */*'})
        with urlopen(request, timeout=12) as response:
            raw = response.read(MAX_FEED + 1)
        if len(raw) > MAX_FEED or re.search(rb'<!\s*(DOCTYPE|ENTITY)', raw, re.I):
            raise ValueError('formato o tamaño de RSS no admitido')
        root = ElementTree.fromstring(raw)
        if root.tag.split('}')[-1].lower() not in {'rss', 'feed', 'rdf'}:
            raise ValueError('respuesta sin RSS ni Atom')
        stories = []
        for item in root.findall('.//{*}item') + root.findall('.//{*}entry'):
            title = feed_text(item.findtext('{*}title') or '')[:600]
            link = next((node.text or node.get('href', '') for node in item.findall('{*}link') if node.get('rel', 'alternate') == 'alternate'), '').strip()
            stamp = next((item.findtext(f'{{*}}{name}') for name in ('pubDate', 'published', 'updated', 'date') if item.findtext(f'{{*}}{name}')), '')
            published = parse_date(stamp)
            if not title or not link.startswith('https://') or published is None or not start <= published <= end:
                continue
            url(link)
            description = feed_text(item.findtext('{*}description') or item.findtext('{*}summary') or '')[:460]
            categories = [category.get('term') or category.text or '' for category in item.findall('{*}category')][:6]
            stories.append({'titulo': title, 'url': link, 'fecha': published.isoformat(), 'fuente': source['nombre'],
                            'grupo': source['grupo'], 'origen': feed_origin(source, item, description), 'entradilla': description,
                            'categorias': categories, 'seccion': source.get('seccion'), 'perfil': source.get('perfil'),
                            'enfoque': source['enfoque']})
        return source, sorted(stories, key=lambda story: story['fecha'], reverse=True)[:25], None
    except (OSError, ValueError, ElementTree.ParseError) as error:
        return source, [], str(error)


def collect(prepare=False):
    sources = read_json(ROOT / 'fuentes.json')
    now = datetime.now(timezone.utc)
    day = madrid_today().isoformat()
    with concurrent.futures.ThreadPoolExecutor(max_workers=6) as executor:
        results = list(executor.map(partial(read_feed, start=now - timedelta(hours=36), end=now + timedelta(minutes=15)), sources))
    seen = set()
    report = [f'<h1>Fuentes para revisar · {spanish_date(day)}</h1>',
              '<p>Titulares recogidos en las últimas 36 horas. Abre los originales y comprueba su procedencia antes de incorporarlos a una edición.</p>']
    collected = []
    for source, items, error in results:
        report.append(f'<h2>{ESC(source["nombre"])} · {ESC(source["enfoque"])}</h2>')
        if error:
            report.append(f'<p>Consulta fallida: {ESC(error)}</p>')
            continue
        unique = []
        for story in items:
            parsed = urlparse(story['url'])
            query = tuple(sorted((name, value) for name, value in parse_qsl(parsed.query) if not name.startswith('utm_')))
            key = (parsed.hostname.removeprefix('www.'), parsed.path.rstrip('/'), query)
            if key not in seen:
                seen.add(key)
                unique.append(story)
        collected.extend(unique)
        report.append('<ul>' + ''.join(f'<li><a href="{url(story["url"])}">{ESC(story["titulo"])}</a></li>' for story in unique) + '</ul>'
                      if unique else '<p>Sin titulares recientes con fecha en este canal.</p>')
    write_atomic(LOCAL / f'{day}.json', json.dumps(collected, ensure_ascii=False, indent=2))
    write_atomic(LOCAL / 'revision.html', '<!doctype html><html lang="es"><meta charset="utf-8">'
                 '<meta name="viewport" content="width=device-width, initial-scale=1"><title>Fuentes para revisar</title>'
                 '<style>body{max-width:55rem;margin:2rem auto;padding:0 1rem;font:16px/1.6 system-ui}li{margin-block:.35rem}</style>'
                 + ''.join(report))
    print(f'{len(collected)} candidatos de {sum(not error for _, _, error in results)}/{len(sources)} canales. {LOCAL / "revision.html"}')
    if prepare:
        from borrador import make_draft, render_review
        glossary = read_json(ROOT / 'glosario.json')
        edition, pending, singles, model_unavailable = make_draft(day, collected, glossary, SECTIONS)
        failures = [source['nombre'] for source, items, error in results if error or not items]
        write_atomic(LOCAL / 'borradores' / f'{day}.json', json.dumps(edition, ensure_ascii=False, indent=2))
        write_atomic(LOCAL / 'borrador.html', render_review(edition, pending, singles, failures, model_unavailable, spanish_date(day), glossary))
        print(f'{len(edition["noticias"])} noticias propuestas. {LOCAL / "borrador.html"}')
    return 0 if collected or (not prepare and any(not error for _, _, error in results)) else 1


def serve(port, lan):
    if not (DIST / 'index.html').exists():
        build()
    host = '0.0.0.0' if lan else '127.0.0.1'
    server = ThreadingHTTPServer((host, port), partial(SimpleHTTPRequestHandler, directory=str(DIST)))
    print(f'Ordenador: http://localhost:{server.server_port}/', flush=True)
    if lan:
        for address in sorted(set(socket.gethostbyname_ex(socket.gethostname())[2])):
            ip = ipaddress.ip_address(address)
            if ip.is_private and not ip.is_loopback and not ip.is_link_local:
                print(f'Misma red Wi-Fi: http://{address}:{server.server_port}/', flush=True)
    with server:
        server.serve_forever()


def main():
    parser = argparse.ArgumentParser(description='Genera La Primera y prepara sus fuentes.')
    sub = parser.add_subparsers(dest='command', required=True)
    sub.add_parser('generar', help='Valida y genera las ediciones revisadas')
    sub.add_parser('recoger', help='Prepara la mesa editorial del día')
    sub.add_parser('preparar', help='Recoge fuentes y genera un borrador privado para revisión')
    preview = sub.add_parser('servir', help='Abre una vista previa local')
    preview.add_argument('--puerto', type=int, default=8765)
    preview.add_argument('--red', action='store_true', help='Permite leer desde la misma Wi-Fi')
    args = parser.parse_args()
    if args.command == 'generar':
        build()
    elif args.command in ('recoger', 'preparar'):
        return collect(prepare=args.command == 'preparar')
    else:
        serve(args.puerto, args.red)
    return 0


if __name__ == '__main__':
    try:
        raise SystemExit(main())
    except KeyboardInterrupt:
        pass
    except (OSError, ValueError, KeyError) as error:
        raise SystemExit(f'La Primera: {error}') from error
